/*const amountInput = document.getElementById("amount");
const amountValue = amountInput.value;

// use the amount value in your payment integration code


function openUPI() {
    // Replace the UPI ID below with your own
    const upiId = "mr.rabadi@upi";
    const amount = ${amountValue}; // Replace with the donation amount
  
    const url = `upi://pay?pa=${upiId}&pn=Donation&am=${amount}`;
  
    window.location.href = url;
  }
  